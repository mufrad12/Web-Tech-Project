<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title></title>
	<link rel="stylesheet" href="css/style.css">
</head>
<body>
	<div class="menu">
		<div class="mid">
			<ul>
				
				<li><a href="employeeManagement.php">Profile</a></li>
				<li><a href="#">Salary/Festival Bonus</a>
					<ul>
						<li><a href="AddSalaryBonus.php">Add Salary/Festival Bonus</a></li>
						<li><a href="ShowSalaryBonus.php">Show Salary/Festival Bonus</a></li>
						
					</ul>
				</li>
				<li><a href="#">Customer Order Information</a>
					<ul>
						<li><a href="CheckCustomerOrder.php">Check Customer Order</a></li>
						<li><a href="#">Check Refund Request</a></li>
					</ul>
				</li>
				<li><a href="#">Transaction History</a>
				<ul>
				    <li><a href="AddTransaction.php">Add in Transaction History</a></li>
					<li><a href="ShowTransaction.php">Show Transaction History</a></li>
				</ul>
				</li>
				<li><a href="#">Income Statement</a>
				<ul>
				    <li><a href="AddStatement.php">Add Statement</a></li>
					<li><a href="ShowStatement.php">Show Statement</a></li>
				</ul>
				</li>
				<li><a href="..\Shop Management\about.php">About</a></li>
				<li><a href="login.php">Logout</a></li>
			</ul>
		</div>
	</div>

	<style>
		.mid{
			text-align: center;
		
		}
	</style>

</body>
</html>